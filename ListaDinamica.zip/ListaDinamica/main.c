#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ListaDinEncad.h"

void exibir_menu() {
    printf("\n===== MENU LISTA ENCADEADA =====\n");
    printf("1. Inserir aluno no início\n");
    printf("2. Inserir aluno no final\n");
    printf("3. Inserir aluno ordenado\n");
    printf("4. Remover aluno por matrícula\n");
    printf("5. Remover aluno do início\n");
    printf("6. Remover aluno do final\n");
    printf("7. Consultar aluno por matrícula\n");
    printf("8. Consultar aluno por posição\n");
    printf("9. Exibir lista\n");
    printf("10. Mostrar tamanho da lista\n");
    printf("0. Sair\n");
    printf("Escolha uma opção: ");
}

int main() {
    Lista* lista = cria_lista();
    Aluno aluno_temp;
    int opcao, matricula, posicao;

    do {
        exibir_menu();
        scanf("%d", &opcao);

        switch (opcao) {
            case 1:
            case 2:
            case 3:
                printf("Digite matrícula: ");
                scanf("%d", &aluno_temp.matricula);
                printf("Digite nome (sem espaços): ");
                scanf("%s", aluno_temp.nome);
                printf("Digite nota 1: ");
                scanf("%f", &aluno_temp.n1);
                printf("Digite nota 2: ");
                scanf("%f", &aluno_temp.n2);
                printf("Digite nota 3: ");
                scanf("%f", &aluno_temp.n3);

                if (opcao == 1 && insere_lista_inicio(lista, aluno_temp))
                    printf("Inserido no início.\n");
                else if (opcao == 2 && insere_lista_final(lista, aluno_temp))
                    printf("Inserido no final.\n");
                else if (opcao == 3 && insere_lista_ordenada(lista, aluno_temp))
                    printf("Inserido ordenado.\n");
                else
                    printf("Falha ao inserir.\n");
                break;

            case 4:
                printf("Informe a matrícula: ");
                scanf("%d", &matricula);
                if (remove_lista(lista, matricula))
                    printf("Aluno removido.\n");
                else
                    printf("Não encontrado.\n");
                break;

            case 5:
                if (remove_lista_inicio(lista))
                    printf("Início removido.\n");
                else
                    printf("Falha ao remover.\n");
                break;

            case 6:
                if (remove_lista_final(lista))
                    printf("Final removido.\n");
                else
                    printf("Falha ao remover.\n");
                break;

            case 7:
                printf("Informe matrícula: ");
                scanf("%d", &matricula);
                if (consulta_lista_mat(lista, matricula, &aluno_temp))
                    printf("%s %.2f %.2f %.2f\n", aluno_temp.nome, aluno_temp.n1, aluno_temp.n2, aluno_temp.n3);
                else
                    printf("Não encontrado.\n");
                break;

            case 8:
                printf("Informe a posição: ");
                scanf("%d", &posicao);
                if (consulta_lista_pos(lista, posicao, &aluno_temp))
                    printf("%s %.2f %.2f %.2f\n", aluno_temp.nome, aluno_temp.n1, aluno_temp.n2, aluno_temp.n3);
                else
                    printf("Posição inválida.\n");
                break;

            case 9:
                imprime_lista(lista);
                break;

            case 10:
                printf("Tamanho: %d\n", tamanho_lista(lista));
                break;

            case 0:
                printf("Saindo...\n");
                break;

            default:
                printf("Opção inválida.\n");
        }

    } while (opcao != 0);

    libera_lista(lista);
    return 0;
}
